import { useEffect, useRef, useState, useCallback } from 'react';
import { authApi, requestsApi, donorApi } from './api.js';

const GROUPS = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
const STATES = ['Tamil Nadu','Kerala','Karnataka','Andhra Pradesh','Telangana','Maharashtra','Delhi','Other'];
const emptyRequest = { patientName:'', bloodGroup:'', units:1, hospitalName:'', city:'', district:'', state:'Tamil Nadu', requiredDate:'', urgency:'URGENT', notes:'' };
const emptyAuth = { name:'', email:'', password:'', phone:'', city:'', district:'', state:'Tamil Nadu', registerAsDonor:false, bloodGroup:'' };
const emptyProfile = { bloodGroup:'', available:true, lastDonationDate:'', city:'', district:'', state:'Tamil Nadu' };
const PAGES = ['home','login','register','dashboard','new-request','requests','matches','donor-profile','incoming','donation-history','notifications'];
const PRIVATE = ['dashboard','new-request','requests','matches','donor-profile','incoming','donation-history','notifications'];
const NAV = [['dashboard','▦','Overview'],['new-request','＋','Request blood'],['requests','♡','My requests'],['donor-profile','♥','Donor profile'],['incoming','↙','Incoming requests'],['donation-history','▤','Donation history'],['notifications','♢','Notifications']];

const fmtDate = v => { if (!v) return ''; const d = new Date(String(v).length === 10 ? v + 'T00:00:00' : v); return isNaN(d) ? String(v) : d.toLocaleDateString(undefined, { day:'numeric', month:'short', year:'numeric' }); };
const fmtTime = v => { if (!v) return ''; const d = new Date(v); return isNaN(d) ? String(v) : d.toLocaleString(undefined, { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' }); };
const todayLocal = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const readHash = () => { const h = window.location.hash.replace(/^#\/?/, '').split('?')[0]; return PAGES.includes(h) ? h : 'home'; };

export default function App() {
  const [page, setPageState] = useState(readHash);
  const [user, setUser] = useState(() => { try { return JSON.parse(sessionStorage.getItem('lifelink_user')); } catch { return null; } });
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [auth, setAuth] = useState(emptyAuth);
  const [request, setRequest] = useState(emptyRequest);
  const [requests, setRequests] = useState([]);
  const [matches, setMatches] = useState([]);
  const [activeRequest, setActiveRequest] = useState(null);
  const [donorProfile, setDonorProfile] = useState(emptyProfile);
  const [incoming, setIncoming] = useState([]);
  const [donorHistory, setDonorHistory] = useState([]);
  const [responses, setResponses] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [consentTarget, setConsentTarget] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const activeRef = useRef(null); activeRef.current = activeRequest;

  const go = useCallback(p => { window.location.hash = '/' + p; }, []);
  useEffect(() => { const f = () => setPageState(readHash()); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  useEffect(() => { if (!user && PRIVATE.includes(page)) go('login'); }, [user, page, go]);

  const resetAll = useCallback(() => {
    setRequests([]); setMatches([]); setActiveRequest(null); setIncoming([]); setDonorHistory([]); setResponses([]); setNotifications([]);
    setDonorProfile(emptyProfile); setAuth(emptyAuth); setRequest(emptyRequest); setConsentTarget(null); setConfirm(null);
  }, []);
  const logout = useCallback((msg = 'You have been logged out.') => {
    sessionStorage.removeItem('lifelink_token'); sessionStorage.removeItem('lifelink_user');
    setUser(null); resetAll(); go('home'); setMessage(msg);
  }, [resetAll, go]);
  useEffect(() => { const f = () => logout('Your session expired. Please log in again.'); window.addEventListener('lifelink:session-expired', f); return () => window.removeEventListener('lifelink:session-expired', f); }, [logout]);

  const loadRequests = useCallback(async () => { try { setRequests(await requestsApi.list()); } catch (e) { setMessage(e.message); } }, []);
  const loadResponses = useCallback(async id => { try { setResponses(await donorApi.responses(id)); } catch (e) { setMessage(e.message); } }, []);
  const loadDonorData = useCallback(async () => {
    const jobs = {
      profile: async () => { const v = await donorApi.profile(); setDonorProfile(p => ({ ...p, bloodGroup: v.bloodGroup || '', available: v.registered ? v.available : true, lastDonationDate: v.lastDonationDate || '', city: v.city || '', district: v.district || '', state: v.state || 'Tamil Nadu' })); },
      incoming: async () => setIncoming(await donorApi.incoming()),
      history: async () => setDonorHistory(await donorApi.history()),
      notifications: async () => setNotifications(await donorApi.notifications())
    };
    await Promise.all(Object.entries(jobs).map(async ([k, fn]) => { try { await fn(); } catch (e) { setMessage(`${k}: ${e.message}`); } }));
  }, []);
  const refreshAll = useCallback(async () => { await Promise.all([loadRequests(), loadDonorData(), activeRef.current ? loadResponses(activeRef.current.id) : null]); }, [loadRequests, loadDonorData, loadResponses]);

  useEffect(() => { if (!user) return; refreshAll(); const t = setInterval(refreshAll, 20000); return () => clearInterval(t); }, [user, refreshAll]);
  useEffect(() => { if (user && PRIVATE.includes(page)) refreshAll(); }, [page]); // refresh whenever a page opens

  const unread = notifications.filter(n => !n.readAt).length;
  const update = (setter, key, value) => setter(prev => ({ ...prev, [key]: value }));
  const guard = async fn => { if (busy) return; setBusy(true); try { await fn(); } catch (e) { setMessage(e.message); } finally { setBusy(false); } };

  const submitAuth = e => { e.preventDefault(); guard(async () => {
    setMessage('');
    const result = page === 'register' ? await authApi.register({ ...auth }) : await authApi.login({ email: auth.email, password: auth.password });
    resetAll();
    sessionStorage.setItem('lifelink_token', result.token); sessionStorage.setItem('lifelink_user', JSON.stringify(result.user));
    setUser(result.user);
    if (page === 'register') { go(auth.registerAsDonor ? 'dashboard' : 'donor-profile'); setMessage(auth.registerAsDonor ? 'Welcome to LifeLink. You are registered as a donor.' : 'Welcome! To appear in donor matches, choose your blood group in your donor profile.'); }
    else { go('dashboard'); setMessage('Welcome back.'); }
  }); };
  const createRequest = e => { e.preventDefault(); guard(async () => {
    await requestsApi.create({ ...request, units: Number(request.units) });
    setRequest(emptyRequest); setMessage('Blood request created.'); await loadRequests(); go('requests');
  }); };
  const viewMatches = item => guard(async () => {
    setActiveRequest(item); activeRef.current = item;
    const [m, r] = await Promise.all([requestsApi.matches(item.id), donorApi.responses(item.id)]);
    setMatches(m); setResponses(r); go('matches');
  });
  const changeRequestStatus = (item, action) => setConfirm({
    title: action === 'cancel' ? 'Cancel this request?' : 'Mark request as completed?',
    text: action === 'cancel' ? 'Invited donors will be notified and contact sharing for this request will end.' : 'Invited donors will be notified and contact sharing for this request will end.',
    onYes: () => guard(async () => { setConfirm(null); await (action === 'cancel' ? requestsApi.cancel(item.id) : requestsApi.complete(item.id)); setMessage(action === 'cancel' ? 'Request cancelled.' : 'Request marked completed.'); await refreshAll(); if (activeRef.current?.id === item.id) { setActiveRequest(null); go('requests'); } })
  });
  const saveDonorProfile = e => { e.preventDefault(); guard(async () => { await donorApi.saveProfile(donorProfile); setMessage('Donor profile saved. You can now appear in matches.'); await loadDonorData(); }); };
  const inviteDonor = id => guard(async () => { await donorApi.invite(activeRequest.id, id); setMessage('Invitation sent to donor.'); await loadResponses(activeRequest.id); });
  const respond = (id, status, share = false) => guard(async () => { setConsentTarget(null); await donorApi.respond(id, status, share); setMessage(status === 'ACCEPTED' ? 'Accepted. Your contact details are shared with this requester only.' : 'You declined this request.'); await loadDonorData(); });
  const withdraw = id => setConfirm({ title: 'Withdraw consent?', text: 'The requester will immediately lose access to your contact details and the invitation returns to Pending.', onYes: () => guard(async () => { setConfirm(null); await donorApi.withdrawConsent(id); setMessage('Consent withdrawn.'); await loadDonorData(); }) });
  const complete = id => guard(async () => { await donorApi.complete(id); setMessage('Donation marked completed.'); await loadDonorData(); });
  const openNotification = n => guard(async () => { if (!n.readAt) { await donorApi.markRead(n.id); await loadDonorData(); } });
  const readAll = () => guard(async () => { await donorApi.readAll(); await loadDonorData(); });

  const layout = content => <main className="dashboard-layout"><aside className="sidebar"><div className="sidebar-label">WORKSPACE</div>
    {NAV.map(([p, icon, label]) => <button key={p} className={'side-link' + (page === p ? ' selected' : '')} onClick={() => go(p)}>{icon} <span>{label}{p === 'notifications' && unread > 0 ? ` (${unread})` : ''}</span></button>)}
    <div className="sidebar-bottom"><span className="avatar user-avatar">{(user?.name || user?.email || 'U').slice(0,1).toUpperCase()}</span><div><strong>{user?.name || user?.email}</strong><small>LifeLink member</small></div></div></aside>
    <section className="dashboard-main">{content}</section></main>;

  const GroupSelect = ({ value, onChange, required }) => <select required={required} value={value} onChange={e => onChange(e.target.value)}><option value="">Choose blood group</option>{GROUPS.map(g => <option key={g}>{g}</option>)}</select>;

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => go(user ? 'dashboard' : 'home')}><span className="brand-mark">♥</span> LifeLink</button>
      <nav className="top-nav">
        <button onClick={() => go('home')}>Home</button>
        <button onClick={() => { go('home'); setTimeout(() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' }), 80); }}>How it works</button>
        {user ? <><button className="nav-cta" onClick={() => go('dashboard')}>Dashboard{unread > 0 ? ` · ${unread}` : ''}</button><button onClick={() => logout()}>Log out</button></> :
          <><button onClick={() => go('login')}>Log in</button><button className="nav-cta" onClick={() => go('register')}>Join LifeLink</button></>}
      </nav>
    </header>
    {message && <div className="notice" role="status"><span>{message}</span><button onClick={() => setMessage('')}>×</button></div>}

    {page === 'home' && <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse-dot"></span> COMMUNITY POWERED · LIFE SAVING</div>
          <h1>Every drop connects.<br/><em>Every connection</em><br/>can save a life.</h1>
          <p>LifeLink brings blood donors, people in need, and verified blood banks closer together — when every moment matters.</p>
          <div className="hero-actions"><button className="primary-btn" onClick={() => go('register')}>Get started <span>↗</span></button><button className="secondary-btn" onClick={() => go('new-request')}>I need blood</button></div>
          <div className="trust-line"><span>✓</span> Privacy-first matching <span>✓</span> Community support</div>
        </div>
        <div className="hero-art">
          <div className="orb orb-one"></div><div className="orb orb-two"></div>
          <div className="heart-card"><div className="heart-symbol">♥</div><div className="heart-caption">One small act.<br/><strong>A lifetime of impact.</strong></div><div className="heart-bottom"><span className="avatar">A</span><span className="avatar avatar-two">R</span><span className="avatar avatar-three">S</span><span className="people-label">People helping people</span></div></div>
          <div className="floating-note"><span className="note-icon">✚</span><div><strong>Be someone's hero</strong><small>Your time can mean everything.</small></div></div>
          <div className="floating-stat"><span>♥</span><div><strong>One community</strong><small>Many lives touched</small></div></div>
        </div>
      </section>
      <section className="impact-strip"><div><strong>01</strong><span>Request blood</span></div><div><strong>02</strong><span>Find a match</span></div><div><strong>03</strong><span>Connect with consent</span></div><div><strong>04</strong><span>Make a difference</span></div></section>
      <section className="how-section" id="how-it-works"><div className="section-heading"><span className="eyebrow">HOW LIFELINK WORKS</span><h2>Help should be easy to find.</h2><p>A clear, thoughtful process that brings the right people together.</p></div>
        <div className="feature-grid"><article className="feature-card"><span className="feature-icon red">♡</span><h3>For donors</h3><p>Register your blood group and availability. Choose when to respond and what contact details to share.</p><button onClick={() => go('register')}>Become a donor ↗</button></article><article className="feature-card"><span className="feature-icon peach">✚</span><h3>For requesters</h3><p>Create a blood request and discover potential matches by blood group and location.</p><button onClick={() => go('register')}>Find support ↗</button></article><article className="feature-card"><span className="feature-icon lavender">⌂</span><h3>For blood banks</h3><p>Approved blood banks can maintain availability information and respond to matching requests.</p><button onClick={() => setMessage('Blood-bank registration workflow is planned for the next backend milestone.')}>Partner with us ↗</button></article></div>
      </section>
      <footer><div className="brand footer-brand"><span className="brand-mark">♥</span> LifeLink</div><p>Built on compassion. Designed around privacy.</p><span>LifeLink is a coordination platform, not a medical service.</span></footer>
    </main>}

    {(page === 'login' || page === 'register') && <main className="auth-layout"><div className="auth-side"><span className="eyebrow">WELCOME TO LIFELINK</span><h2>Small acts of kindness can make a world of difference.</h2><p>Join a community connecting people through the gift of blood donation.</p><div className="auth-quote">“The smallest act of kindness is worth more than the grandest intention.”</div></div><form className="auth-card" onSubmit={submitAuth}><span className="eyebrow">{page === 'register' ? 'CREATE YOUR ACCOUNT' : 'GOOD TO SEE YOU'}</span><h1>{page === 'register' ? 'Join LifeLink' : 'Welcome back'}</h1><p>{page === 'register' ? 'Create one account to request blood and register as a donor.' : 'Log in to continue to your dashboard.'}</p>
      {page === 'register' && <><label>Full name<input required value={auth.name} onChange={e => update(setAuth,'name',e.target.value)} placeholder="Your full name"/></label><label>Phone number<input required value={auth.phone} onChange={e => update(setAuth,'phone',e.target.value)} placeholder="+91 98765 43210" pattern="(\+91[ -]?)?[6-9][0-9]{4}[ -]?[0-9]{5}"/></label><div className="form-row"><label>City<input required value={auth.city} onChange={e => update(setAuth,'city',e.target.value)} placeholder="Chennai"/></label><label>District<input required value={auth.district} onChange={e => update(setAuth,'district',e.target.value)} placeholder="Chennai"/></label></div><label>State<select value={auth.state} onChange={e => update(setAuth,'state',e.target.value)}>{['Tamil Nadu','Kerala','Karnataka','Andhra Pradesh','Telangana','Maharashtra','Delhi','Other'].map(s=><option key={s}>{s}</option>)}</select></label><label className="check-label"><input type="checkbox" checked={auth.registerAsDonor} onChange={e=>update(setAuth,'registerAsDonor',e.target.checked)}/> I also want to register as a donor</label>{auth.registerAsDonor && <label>Blood group<select required value={auth.bloodGroup} onChange={e=>update(setAuth,'bloodGroup',e.target.value)}><option value="">Choose blood group</option>{['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(g=><option key={g}>{g}</option>)}</select></label>}</>}
      <label>Email address<input type="email" required value={auth.email} onChange={e => update(setAuth,'email',e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" minLength="8" required value={auth.password} onChange={e => update(setAuth,'password',e.target.value)} placeholder="At least 8 characters"/></label><button className="primary-btn full-btn" disabled={busy}>{busy ? 'Please wait…' : page === 'register' ? 'Create account →' : 'Log in →'}</button><div className="auth-switch">{page === 'register' ? 'Already have an account?' : 'New to LifeLink?'} <button type="button" onClick={() => {setMessage('');go(page === 'register' ? 'login' : 'register')}}>{page === 'register' ? 'Log in' : 'Create an account'}</button></div></form></main>}


    {!user && page === 'new-request' && <main className="auth-layout"><div className="auth-side"><span className="eyebrow">REQUEST BLOOD</span><h2>Start by creating your account.</h2></div><div className="auth-card"><h1>Need blood?</h1><p>Create an account to submit a request and track responses.</p><button className="primary-btn full-btn" onClick={() => go('register')}>Create account →</button><button className="secondary-btn full-btn" onClick={() => go('login')}>I already have an account</button></div></main>}

    {user && page === 'dashboard' && layout(<>
      <div className="dash-welcome"><div><span className="eyebrow">YOUR LIFE LINK</span><h1>Good to see you, {(user.name || 'there').split(' ')[0]}.</h1><p>Every connection starts with a caring community.</p></div><button className="primary-btn" onClick={() => go('new-request')}>+ Create request</button></div>
      <div className="stats-grid"><div className="stat-card"><small>Total requests</small><strong>{requests.length}</strong></div><div className="stat-card"><small>Open requests</small><strong>{requests.filter(r => r.status === 'OPEN').length}</strong></div><div className="stat-card"><small>Pending invitations for you</small><strong>{incoming.filter(i => i.responseStatus === 'PENDING').length}</strong></div></div>
      <div className="dash-section-heading"><div><h2>Recent requests</h2></div><button className="text-btn" onClick={() => go('requests')}>View all →</button></div>
      <RequestList requests={requests.slice(0, 4)} viewMatches={viewMatches} onStatus={changeRequestStatus} busy={busy} />
      <div className="privacy-banner"><span>♧</span><div><strong>Your privacy matters</strong><p>Donor contact details stay private unless the donor explicitly agrees to share them for a specific request.</p></div></div></>)}

    {user && page === 'new-request' && layout(<><div className="workspace-title"><span className="eyebrow">REQUEST SUPPORT</span><h1>Create a blood request</h1></div>
      <form className="request-form" onSubmit={createRequest}>
        <div className="form-row"><label>Patient name<input required maxLength="120" value={request.patientName} onChange={e => update(setRequest, 'patientName', e.target.value)} /></label><label>Blood group<GroupSelect required value={request.bloodGroup} onChange={v => update(setRequest, 'bloodGroup', v)} /></label></div>
        <div className="form-row"><label>Units required<input type="number" min="1" max="20" required value={request.units} onChange={e => update(setRequest, 'units', e.target.value)} /></label><label>Urgency<select value={request.urgency} onChange={e => update(setRequest, 'urgency', e.target.value)}><option value="NORMAL">Normal</option><option value="URGENT">Urgent</option><option value="CRITICAL">Critical</option></select></label></div>
        <label>Hospital name<input required maxLength="180" value={request.hospitalName} onChange={e => update(setRequest, 'hospitalName', e.target.value)} /></label>
        <div className="form-row"><label>City<input required maxLength="100" value={request.city} onChange={e => update(setRequest, 'city', e.target.value)} /></label><label>District<input required maxLength="100" value={request.district} onChange={e => update(setRequest, 'district', e.target.value)} /></label></div>
        <div className="form-row"><label>State<select value={request.state} onChange={e => update(setRequest, 'state', e.target.value)}>{STATES.map(s => <option key={s}>{s}</option>)}</select></label><label>Required date<input type="date" required min={todayLocal()} value={request.requiredDate} onChange={e => update(setRequest, 'requiredDate', e.target.value)} /></label></div>
        <label>Additional notes<textarea rows="3" maxLength="1000" value={request.notes} onChange={e => update(setRequest, 'notes', e.target.value)} placeholder="Optional (avoid unnecessary sensitive information)" /></label>
        <button className="primary-btn" disabled={busy}>{busy ? 'Submitting…' : 'Submit blood request →'}</button></form></>)}

    {user && page === 'requests' && layout(<><div className="workspace-title"><span className="eyebrow">YOUR ACTIVITY</span><h1>My blood requests</h1><button className="primary-btn" onClick={() => go('new-request')}>+ New request</button> <button className="outline-btn" onClick={loadRequests}>↻ Refresh</button></div>
      <RequestList requests={requests} viewMatches={viewMatches} onStatus={changeRequestStatus} busy={busy} /></>)}

    {user && page === 'matches' && layout(!activeRequest ? <div className="empty-state"><h3>Select a request first</h3><button className="outline-btn" onClick={() => go('requests')}>Go to my requests</button></div> : <>
      <div className="workspace-title"><span className="eyebrow">POTENTIAL MATCHES</span><h1>Matches for request #{activeRequest.id}</h1><p>Only first names are shown. Contact details appear only after a donor accepts and consents. Status: {requests.find(r => r.id === activeRequest.id)?.status || activeRequest.status}</p><button className="outline-btn" onClick={() => viewMatches(activeRequest)}>↻ Refresh</button></div>
      {matches.length ? <div className="request-list">{matches.map(m => <article className="request-card" key={m.donorUserId}><div className="blood-badge">{m.bloodGroup}</div><div className="request-info"><h3>{m.displayName}</h3><p>{m.city}, {m.district}</p><span className="status-pill">Available</span></div>{responses.some(r => r.donorUserId === m.donorUserId) ? <button className="outline-btn" disabled>Request sent</button> : <button className="outline-btn" disabled={busy} onClick={() => inviteDonor(m.donorUserId)}>Send request</button>}</article>)}</div> : <div className="empty-state"><span>♡</span><h3>No matches right now</h3><p>Donors must have the same blood group, be available, and share your state and city or district.</p></div>}
      <div className="workspace-title" style={{ marginTop: 30 }}><h2>Donor responses</h2></div>
      {responses.length ? <div className="request-list">{responses.map(r => <article className="request-card" key={r.recipientId}><div className="request-info"><h3>{r.donorName} · {r.responseStatus}</h3><p>{r.city}, {r.district} · {r.bloodGroup}</p>{r.contactVisible && <p>Phone: {r.phone} · Email: {r.email}</p>}{!r.contactVisible && r.responseStatus === 'ACCEPTED' && <p>Contact no longer shared.</p>}</div></article>)}</div> : <p>No donor responses yet.</p>}</>)}

    {user && page === 'donor-profile' && layout(<><div className="workspace-title"><span className="eyebrow">DONOR DETAILS</span><h1>Donor profile & availability</h1><p>Saving this makes you appear in matches for your blood group and location.</p></div>
      <form className="request-form" onSubmit={saveDonorProfile}>
        <label>Blood group<GroupSelect required value={donorProfile.bloodGroup} onChange={v => update(setDonorProfile, 'bloodGroup', v)} /></label>
        <div className="form-row"><label>City<input required maxLength="100" value={donorProfile.city} onChange={e => update(setDonorProfile, 'city', e.target.value)} /></label><label>District<input required maxLength="100" value={donorProfile.district} onChange={e => update(setDonorProfile, 'district', e.target.value)} /></label></div>
        <label>State<select value={donorProfile.state} onChange={e => update(setDonorProfile, 'state', e.target.value)}>{STATES.map(s => <option key={s}>{s}</option>)}</select></label>
        <label>Last donation date (optional)<input type="date" max={todayLocal()} value={donorProfile.lastDonationDate} onChange={e => update(setDonorProfile, 'lastDonationDate', e.target.value)} /></label>
        <label className="check-label"><input type="checkbox" checked={donorProfile.available} onChange={e => update(setDonorProfile, 'available', e.target.checked)} /> I am currently available to donate</label>
        <button className="primary-btn" disabled={busy}>Save donor profile</button></form></>)}

    {user && page === 'incoming' && layout(<><div className="workspace-title"><span className="eyebrow">DONOR INBOX</span><h1>Incoming blood requests</h1><p>Accepting asks for your permission to share contact details with that requester only.</p><button className="outline-btn" onClick={loadDonorData}>↻ Refresh</button></div>
      {incoming.length ? <div className="request-list">{incoming.map(x => { const open = x.requestStatus === 'OPEN'; return <article className="request-card" key={x.recipientId}><div className="blood-badge">{x.bloodGroup}</div><div className="request-info"><h3>{x.patientName} · {x.responseStatus}{!open && <span className="status-pill">Request {x.requestStatus}</span>}</h3><p>{x.hospitalName} · {x.city}, {x.district}</p><small>{x.units} unit(s) · Needed {fmtDate(x.requiredDate)}</small></div>
        {open && x.responseStatus === 'PENDING' && <><button className="primary-btn" disabled={busy} onClick={() => setConsentTarget(x.recipientId)}>Accept</button><button className="outline-btn" disabled={busy} onClick={() => respond(x.recipientId, 'REJECTED')}>Reject</button></>}
        {open && x.responseStatus === 'ACCEPTED' && <><button className="outline-btn" disabled={busy} onClick={() => complete(x.recipientId)}>Mark completed</button><button className="outline-btn" disabled={busy} onClick={() => withdraw(x.recipientId)}>Withdraw consent</button></>}</article>; })}</div> : <div className="empty-state"><h3>No incoming requests</h3><p>Matching invitations will appear here.</p></div>}</>)}

    {user && page === 'donation-history' && layout(<><div className="workspace-title"><span className="eyebrow">YOUR CONTRIBUTIONS</span><h1>Donation history</h1><p>Accepted and completed donations.</p></div>
      {donorHistory.length ? <div className="request-list">{donorHistory.map(x => <article className="request-card" key={x.recipientId}><div className="blood-badge">{x.bloodGroup}</div><div className="request-info"><h3>{x.patientName}</h3><p>{x.hospitalName} · {x.city}</p><small>{fmtTime(x.completedAt || x.respondedAt)}</small><span className="status-pill">{x.responseStatus}</span></div></article>)}</div> : <div className="empty-state">No donation activity yet.</div>}</>)}

    {user && page === 'notifications' && layout(<><div className="workspace-title"><span className="eyebrow">UPDATES</span><h1>Notifications {unread > 0 && `(${unread} unread)`}</h1>{unread > 0 && <button className="outline-btn" onClick={readAll}>Mark all as read</button>}</div>
      {notifications.length ? <div className="request-list">{notifications.map(n => <article className="request-card" key={n.id} style={n.readAt ? { opacity: .7 } : { borderColor: '#c64a62' }}><div className="request-info"><h3>{n.title}</h3><p>{n.body}</p><small>{fmtTime(n.createdAt)}</small></div>
        {n.requestId && <button className="outline-btn" onClick={async () => { await openNotification(n); const mine = requests.find(r => r.id === n.requestId); if (mine) viewMatches(mine); else go('incoming'); }}>Open</button>}
        {!n.readAt && <button className="outline-btn" onClick={() => openNotification(n)}>Mark read</button>}</article>)}</div> : <div className="empty-state">You're all caught up.</div>}</>)}

    {consentTarget && <div className="modal-backdrop" role="presentation" onKeyDown={e => e.key === 'Escape' && setConsentTarget(null)}><section className="consent-modal" role="dialog" aria-modal="true" aria-labelledby="consent-title"><h2 id="consent-title">Share your contact information?</h2><p>Are you okay with sharing your name, phone and email with this requester so they can contact you about the donation? Only this requester will see them, and you can withdraw consent later.</p><div className="modal-actions"><button className="outline-btn" onClick={() => setConsentTarget(null)}>Cancel</button><button className="outline-btn" onClick={() => { setConsentTarget(null); setMessage('Not accepted. The invitation stays Pending and your contact details remain private.'); }}>No</button><button className="primary-btn" autoFocus disabled={busy} onClick={() => respond(consentTarget, 'ACCEPTED', true)}>Yes, I agree</button></div></section></div>}
    {confirm && <div className="modal-backdrop" role="presentation"><section className="consent-modal" role="dialog" aria-modal="true"><h2>{confirm.title}</h2><p>{confirm.text}</p><div className="modal-actions"><button className="outline-btn" onClick={() => setConfirm(null)}>Go back</button><button className="primary-btn" disabled={busy} onClick={confirm.onYes}>Confirm</button></div></section></div>}
    <div className="safety-note"><span>✦</span> LifeLink helps coordinate connections. It does not determine medical eligibility or guarantee blood availability. Contact qualified healthcare professionals for medical guidance.</div>
  </div>;
}

function RequestList({ requests, viewMatches, onStatus, busy }) {
  if (!requests.length) return <div className="empty-state"><span>♡</span><h3>No requests yet</h3><p>When you create a blood request, it will appear here.</p></div>;
  return <div className="request-list">{requests.map(r => <article className="request-card" key={r.id}><div className="blood-badge">{r.bloodGroup}</div><div className="request-info"><h3>{r.patientName || 'Blood request'} <span className="status-pill">{r.status}</span></h3><p>{r.hospitalName} · {r.city}, {r.district}</p><small>{r.units} unit(s) · Needed {fmtDate(r.requiredDate)} · {r.urgency}</small></div>
    <button className="outline-btn" disabled={busy} onClick={() => viewMatches(r)}>View matches ↗</button>
    {r.status === 'OPEN' && <><button className="outline-btn" disabled={busy} onClick={() => onStatus(r, 'complete')}>Complete</button><button className="outline-btn" disabled={busy} onClick={() => onStatus(r, 'cancel')}>Cancel</button></>}</article>)}</div>;
}
