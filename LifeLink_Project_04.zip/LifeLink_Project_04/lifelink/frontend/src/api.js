const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api';

function token() { return sessionStorage.getItem('lifelink_token'); }

export async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token()) headers.Authorization = `Bearer ${token()}`;
  const response = await fetch(`${API_URL}${path}`, { ...options, headers });
  const body = response.status === 204 ? null : await response.json().catch(() => null);
  if (response.status === 401 && token() && !path.startsWith('/auth/')) { sessionStorage.removeItem('lifelink_token'); sessionStorage.removeItem('lifelink_user'); window.dispatchEvent(new Event('lifelink:session-expired')); }
  if (!response.ok) throw new Error(body?.message || body?.error || `Request failed (${response.status})`);
  return body;
}

export const authApi = {
  register: (payload) => api('/auth/register', { method: 'POST', body: JSON.stringify(payload) }),
  login: (payload) => api('/auth/login', { method: 'POST', body: JSON.stringify(payload) })
};
export const requestsApi = {
  list: () => api('/requests'),
  create: (payload) => api('/requests', { method: 'POST', body: JSON.stringify(payload) }),
  matches: (id) => api(`/requests/${id}/matches`),
  complete: (id) => api(`/requests/${id}/complete`, { method: 'POST' }),
  cancel: (id) => api(`/requests/${id}/cancel`, { method: 'POST' })
};

export const donorApi = {
  profile: () => api('/donors/profile'),
  saveProfile: (payload) => api('/donors/profile', { method: 'POST', body: JSON.stringify(payload) }),
  incoming: () => api('/donors/incoming'),
  respond: (id,status,shareContact=false) => api(`/donors/incoming/${id}/respond`, { method:'POST', body:JSON.stringify({status,shareContact}) }),
  history: () => api('/donors/history'),
  complete: (id) => api(`/donors/incoming/${id}/complete`, {method:'POST'}),
  notifications: () => api('/notifications'),
  readAll: () => api('/notifications/read-all', {method:'POST'}),
  markRead: (id) => api(`/notifications/${id}/read`, {method:'POST'}),
  withdrawConsent: (id) => api(`/donors/incoming/${id}/withdraw-consent`, {method:'POST'}),
  invite: (requestId,donorUserId) => api(`/requests/${requestId}/invite`, {method:'POST',body:JSON.stringify({donorUserId})}),
  responses: (requestId) => api(`/requests/${requestId}/responses`)
};
