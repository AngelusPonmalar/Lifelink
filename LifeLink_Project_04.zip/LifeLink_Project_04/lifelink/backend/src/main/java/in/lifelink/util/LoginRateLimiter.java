package in.lifelink.util;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.LongSupplier;

/** In-memory sliding-window limiter for failed logins (single-instance deployments). */
public class LoginRateLimiter {
    private final int maxFailures; private final long windowMs; private final LongSupplier clock;
    private final ConcurrentHashMap<String, Deque<Long>> failures = new ConcurrentHashMap<>();
    public LoginRateLimiter(int maxFailures, Duration window) { this(maxFailures, window, System::currentTimeMillis); }
    public LoginRateLimiter(int maxFailures, Duration window, LongSupplier clock) { this.maxFailures = maxFailures; this.windowMs = window.toMillis(); this.clock = clock; }
    public boolean isBlocked(String key) {
        Deque<Long> q = failures.get(key); if (q == null) return false;
        synchronized (q) { prune(q); return q.size() >= maxFailures; }
    }
    public void recordFailure(String key) {
        Deque<Long> q = failures.computeIfAbsent(key, k -> new ArrayDeque<>());
        synchronized (q) { prune(q); q.addLast(clock.getAsLong()); }
    }
    public void reset(String key) { failures.remove(key); }
    private void prune(Deque<Long> q) { long cutoff = clock.getAsLong() - windowMs; while (!q.isEmpty() && q.peekFirst() < cutoff) q.pollFirst(); }
}
