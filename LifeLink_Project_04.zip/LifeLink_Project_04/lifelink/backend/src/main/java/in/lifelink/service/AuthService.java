package in.lifelink.service;

import in.lifelink.model.User;
import in.lifelink.repo.UserRepository;
import in.lifelink.security.JwtService;
import in.lifelink.util.ApiException;
import in.lifelink.util.Audit;
import in.lifelink.util.LoginRateLimiter;
import in.lifelink.util.Validators;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Duration;
import java.util.Map;

@Service
public class AuthService {
    private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt; private final JdbcTemplate db; private final Audit audit;
    private final LoginRateLimiter limiter = new LoginRateLimiter(5, Duration.ofMinutes(15));
    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt, JdbcTemplate db, Audit audit){this.users=users;this.encoder=encoder;this.jwt=jwt;this.db=db;this.audit=audit;}

    @Transactional
    public Map<String,Object> register(Map<String,String> body) {
        String email=Validators.email(body.get("email"));
        String password=Validators.password(body.get("password"));
        String phone=Validators.phone(body.get("phone"));
        if(users.existsByEmailIgnoreCase(email)) throw ApiException.conflict("An account with this email already exists.");
        boolean donor="true".equalsIgnoreCase(body.get("registerAsDonor"));
        String group=donor?Validators.bloodGroup(body.get("bloodGroup")):null;
        User u=new User(); u.setName(Validators.text(body.get("name"),"name",120)); u.setEmail(email);
        u.setPasswordHash(encoder.encode(password)); u.setPhone(phone);
        u.setCity(Validators.text(body.get("city"),"city",100)); u.setDistrict(Validators.text(body.get("district"),"district",100)); u.setState(Validators.text(body.get("state"),"state",100));
        u.setRole("USER");
        u=users.save(u);
        if(donor) db.update("INSERT INTO donor_profiles(user_id,blood_group,available,last_donation_date) VALUES(?,?,?,NULL)",u.getId(),group,Boolean.parseBoolean(body.getOrDefault("available","true")));
        audit.log(u.getId(),"REGISTER","USER",u.getId(),donor?"as donor":"requester only");
        return authResult(u);
    }
    public Map<String,Object> login(Map<String,String> body) {
        String email=Validators.text(body.get("email"),"email",190).toLowerCase();
        String password=body.get("password"); if(password==null||password.isEmpty()) throw new IllegalArgumentException("password is required.");
        if(limiter.isBlocked(email)) throw ApiException.tooMany("Too many failed login attempts. Try again in 15 minutes.");
        User u=users.findByEmailIgnoreCase(email).filter(x->encoder.matches(password,x.getPasswordHash())).orElse(null);
        if(u==null){ limiter.recordFailure(email); throw ApiException.unauthorized("Invalid email or password."); }
        limiter.reset(email);
        return authResult(u);
    }
    private Map<String,Object> authResult(User u) {
        return Map.of("token",jwt.createToken(u.getId(),u.getEmail(),u.getRole()),
            "user",Map.of("id",u.getId(),"name",u.getName(),"email",u.getEmail(),"role",u.getRole()));
    }
}
