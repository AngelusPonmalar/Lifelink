package in.lifelink.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="donor_profiles")
public class DonorProfile {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @OneToOne(optional=false) @JoinColumn(name="user_id", nullable=false, unique=true) private User user;
    @Column(name="blood_group", nullable=false, length=3) private String bloodGroup;
    @Column(nullable=false) private boolean available = true;
    @Column(name="last_donation_date") private LocalDate lastDonationDate;
    public Long getId(){return id;} public User getUser(){return user;} public void setUser(User v){user=v;}
    public String getBloodGroup(){return bloodGroup;} public void setBloodGroup(String v){bloodGroup=v;}
    public boolean isAvailable(){return available;} public void setAvailable(boolean v){available=v;}
    public LocalDate getLastDonationDate(){return lastDonationDate;} public void setLastDonationDate(LocalDate v){lastDonationDate=v;}
}
