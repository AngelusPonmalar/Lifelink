package in.lifelink.util;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class Audit {
    private final JdbcTemplate db;
    public Audit(JdbcTemplate db) { this.db = db; }
    public void log(Long actor, String action, String entityType, Long entityId, String details) {
        try { db.update("INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?)", actor, action, entityType, entityId, details); }
        catch (RuntimeException ignored) { /* auditing must never break the main flow */ }
    }
}
