package in.lifelink.model;

import jakarta.persistence.*;
import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name="blood_requests")
public class BloodRequest {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false) @JoinColumn(name="requester_id", nullable=false) private User requester;
    @Column(name="patient_name", nullable=false, length=120) private String patientName;
    @Column(name="blood_group", nullable=false, length=3) private String bloodGroup;
    @Column(name="units_required", nullable=false) private int units;
    @Column(name="hospital_name", nullable=false, length=180) private String hospitalName;
    @Column(nullable=false, length=100) private String city;
    @Column(nullable=false, length=100) private String district;
    @Column(nullable=false, length=100) private String state;
    @Column(name="required_date", nullable=false) private LocalDate requiredDate;
    @Column(nullable=false, length=20) private String urgency = "URGENT";
    @Column(length=1000) private String notes;
    @Column(nullable=false, length=20) private String status = "OPEN";
    @Column(name="created_at", insertable=false, updatable=false) private Instant createdAt;
    public Long getId(){return id;} public User getRequester(){return requester;} public void setRequester(User v){requester=v;}
    public String getPatientName(){return patientName;} public void setPatientName(String v){patientName=v;}
    public String getBloodGroup(){return bloodGroup;} public void setBloodGroup(String v){bloodGroup=v;}
    public int getUnits(){return units;} public void setUnits(int v){units=v;}
    public String getHospitalName(){return hospitalName;} public void setHospitalName(String v){hospitalName=v;}
    public String getCity(){return city;} public void setCity(String v){city=v;}
    public String getDistrict(){return district;} public void setDistrict(String v){district=v;}
    public String getState(){return state;} public void setState(String v){state=v;}
    public LocalDate getRequiredDate(){return requiredDate;} public void setRequiredDate(LocalDate v){requiredDate=v;}
    public String getUrgency(){return urgency;} public void setUrgency(String v){urgency=v;}
    public String getNotes(){return notes;} public void setNotes(String v){notes=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public Instant getCreatedAt(){return createdAt;}
}
