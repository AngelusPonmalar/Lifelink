package in.lifelink.service;

import in.lifelink.model.BloodRequest;
import in.lifelink.model.DonorProfile;
import in.lifelink.model.User;
import in.lifelink.repo.BloodRequestRepository;
import in.lifelink.repo.DonorProfileRepository;
import in.lifelink.repo.UserRepository;
import in.lifelink.util.ApiException;
import in.lifelink.util.Audit;
import in.lifelink.util.Validators;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

@Service
public class RequestService {
    private final BloodRequestRepository requests; private final UserRepository users; private final DonorProfileRepository donors; private final JdbcTemplate db; private final Audit audit;
    private final ZoneId zone; private final int donationGapDays;
    public RequestService(BloodRequestRepository requests,UserRepository users,DonorProfileRepository donors,JdbcTemplate db,Audit audit,
                          @Value("${app.timezone:Asia/Kolkata}") String tz,@Value("${app.donation-gap-days:90}") int gap){
        this.requests=requests;this.users=users;this.donors=donors;this.db=db;this.audit=audit;this.zone=ZoneId.of(tz);this.donationGapDays=gap;}

    public LocalDate today(){return LocalDate.now(zone);}

    @Transactional
    public Map<String,Object> create(String email, Map<String,Object> b) {
        User user=owner(email);
        BloodRequest r=new BloodRequest(); r.setRequester(user);
        r.setPatientName(Validators.text(b.get("patientName"),"patientName",120));
        r.setBloodGroup(Validators.bloodGroup(b.get("bloodGroup")));
        r.setUnits(Validators.units(b.get("units")));
        r.setHospitalName(Validators.text(b.get("hospitalName"),"hospitalName",180));
        r.setCity(Validators.text(b.get("city"),"city",100)); r.setDistrict(Validators.text(b.get("district"),"district",100)); r.setState(Validators.text(b.get("state"),"state",100));
        r.setRequiredDate(Validators.requiredDate(b.get("requiredDate"),today()));
        r.setUrgency(Validators.urgency(b.get("urgency")));
        r.setNotes(Validators.optionalText(b.get("notes"),1000,"notes"));
        BloodRequest saved=requests.save(r);
        audit.log(user.getId(),"REQUEST_CREATED","BLOOD_REQUEST",saved.getId(),null);
        return toDto(saved);
    }
    public List<Map<String,Object>> list(String email) {
        User u=owner(email); return requests.findByRequesterIdOrderByCreatedAtDesc(u.getId()).stream().map(this::toDto).toList();
    }
    public BloodRequest ownedRequest(Long id, Long requesterId) {
        return requests.findByIdAndRequesterId(id,requesterId).orElseThrow(()->ApiException.notFound("Request not found."));
    }
    public boolean isOpen(BloodRequest r){return "OPEN".equals(r.getStatus()) && !r.getRequiredDate().isBefore(today());}

    /** Single rule used by both matching and invitation. Coordination filter only - not medical clearance. */
    public boolean eligible(BloodRequest r, DonorProfile d) {
        User du=d.getUser();
        if(!d.isAvailable()||!r.getBloodGroup().equals(d.getBloodGroup())) return false;
        if(du.getId().equals(r.getRequester().getId())) return false;
        if(!Validators.sameLocation(du.getState(),du.getCity(),du.getDistrict(),r.getState(),r.getCity(),r.getDistrict())) return false;
        if(donationGapDays>0 && d.getLastDonationDate()!=null && d.getLastDonationDate().plusDays(donationGapDays).isAfter(r.getRequiredDate())) return false;
        return true;
    }
    public boolean eligibleDonor(BloodRequest r, Long donorUserId) {
        return donors.findByUserId(donorUserId).map(d->eligible(r,d)).orElse(false);
    }
    public List<Map<String,Object>> matches(String email, Long id) {
        User requester=owner(email);
        BloodRequest r=ownedRequest(id,requester.getId());
        if(!isOpen(r)) return List.of();
        return donors.findByBloodGroupAndAvailableTrue(r.getBloodGroup()).stream().filter(d->eligible(r,d))
            .map(d->{Map<String,Object> m=new LinkedHashMap<>();m.put("id",d.getId());m.put("donorUserId",d.getUser().getId());m.put("displayName",firstName(d.getUser().getName()));
                m.put("bloodGroup",d.getBloodGroup());m.put("city",d.getUser().getCity());m.put("district",d.getUser().getDistrict());m.put("available",d.isAvailable());return m;})
            .toList();
    }
    @Transactional
    public Map<String,Object> updateStatus(String email,Long id,String status) {
        User u=owner(email); BloodRequest r=ownedRequest(id,u.getId());
        if(!List.of("COMPLETED","CANCELLED").contains(status)) throw new IllegalArgumentException("Unsupported status.");
        if(!"OPEN".equals(r.getStatus())) throw ApiException.conflict("Only open requests can be updated.");
        BloodRequest saved=close(r,status,"A blood request you were invited to has been "+status.toLowerCase(Locale.ROOT)+". Contact sharing for it has ended.");
        audit.log(u.getId(),"REQUEST_"+status,"BLOOD_REQUEST",id,null);
        return toDto(saved);
    }
    /** Closes request, closes pending invitations, revokes all consents (contact hidden), notifies invited donors. */
    private BloodRequest close(BloodRequest r,String status,String body){
        r.setStatus(status); BloodRequest saved=requests.save(r); long id=r.getId();
        List<Long> recipients=db.query("SELECT donor_user_id FROM request_recipients WHERE request_id=?",(rs,n)->rs.getLong(1),id);
        db.update("UPDATE request_recipients SET response_status='CLOSED' WHERE request_id=? AND response_status='PENDING'",id);
        db.update("UPDATE request_recipients SET contact_share_approved=FALSE WHERE request_id=?",id);
        db.update("UPDATE contact_consents SET granted=FALSE,revoked_at=CURRENT_TIMESTAMP WHERE request_id=? AND granted=TRUE",id);
        String title="Blood request "+status.toLowerCase(Locale.ROOT);
        for(Long donorId:recipients) db.update("INSERT INTO notifications(user_id,title,body,request_id) VALUES(?,?,?,?)",donorId,title,body,id);
        return saved;
    }
    @Scheduled(cron="0 10 * * * *") @Transactional
    public int expireOverdue(){
        List<BloodRequest> overdue=requests.findAll().stream().filter(r->"OPEN".equals(r.getStatus())&&r.getRequiredDate().isBefore(today())).toList();
        for(BloodRequest r:overdue){ close(r,"EXPIRED","A blood request you were invited to has expired because its required date passed."); audit.log(null,"REQUEST_EXPIRED","BLOOD_REQUEST",r.getId(),null); }
        return overdue.size();
    }
    private User owner(String email){return users.findByEmailIgnoreCase(email).orElseThrow(()->ApiException.unauthorized("Account not found. Please log in again."));}
    private String firstName(String name){return name==null?"Donor":name.trim().split("\\s+")[0];}
    private Map<String,Object> toDto(BloodRequest r) {
        Map<String,Object> m=new LinkedHashMap<>();m.put("id",r.getId());m.put("patientName",r.getPatientName());m.put("bloodGroup",r.getBloodGroup());
        m.put("units",r.getUnits());m.put("hospitalName",r.getHospitalName());m.put("city",r.getCity());m.put("district",r.getDistrict());
        m.put("state",r.getState());m.put("requiredDate",r.getRequiredDate());m.put("urgency",r.getUrgency());m.put("notes",r.getNotes());
        m.put("status",r.getStatus());m.put("createdAt",r.getCreatedAt());return m;
    }
}
