package in.lifelink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import java.util.TimeZone;

@SpringBootApplication
@EnableScheduling
public class LifeLinkApplication {
    public static void main(String[] args) {
        // Use one consistent zone for "today" checks (default India). Override with APP_TIMEZONE.
        String tz = System.getenv().getOrDefault("APP_TIMEZONE", "Asia/Kolkata");
        TimeZone.setDefault(TimeZone.getTimeZone(tz));
        SpringApplication.run(LifeLinkApplication.class, args);
    }
}
