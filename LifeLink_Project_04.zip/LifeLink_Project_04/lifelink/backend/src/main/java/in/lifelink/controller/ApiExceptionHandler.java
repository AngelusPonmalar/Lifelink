package in.lifelink.controller;

import in.lifelink.util.ApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);
    private ResponseEntity<Map<String,String>> r(HttpStatus s, String m) { return ResponseEntity.status(s).body(Map.of("message", m)); }
    @ExceptionHandler(ApiException.class) public ResponseEntity<Map<String,String>> api(ApiException ex) { return r(ex.getStatus(), ex.getMessage()); }
    @ExceptionHandler(IllegalArgumentException.class) public ResponseEntity<Map<String,String>> badRequest(IllegalArgumentException ex) { return r(HttpStatus.BAD_REQUEST, ex.getMessage()); }
    @ExceptionHandler(EmptyResultDataAccessException.class) public ResponseEntity<Map<String,String>> noRow(EmptyResultDataAccessException ex) { return r(HttpStatus.NOT_FOUND, "The requested item was not found."); }
    @ExceptionHandler(DuplicateKeyException.class) public ResponseEntity<Map<String,String>> dup(DuplicateKeyException ex) { return r(HttpStatus.CONFLICT, "This action has already been recorded."); }
    @ExceptionHandler(HttpMessageNotReadableException.class) public ResponseEntity<Map<String,String>> malformed(HttpMessageNotReadableException ex) { return r(HttpStatus.BAD_REQUEST, "Request body is missing or malformed."); }
    @ExceptionHandler(MethodArgumentTypeMismatchException.class) public ResponseEntity<Map<String,String>> badArg(MethodArgumentTypeMismatchException ex) { return r(HttpStatus.BAD_REQUEST, "Invalid value for " + ex.getName() + "."); }
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class) public ResponseEntity<Map<String,String>> method(HttpRequestMethodNotSupportedException ex) { return r(HttpStatus.METHOD_NOT_ALLOWED, "Method not allowed."); }
    @ExceptionHandler(NoResourceFoundException.class) public ResponseEntity<Map<String,String>> nores(NoResourceFoundException ex) { return r(HttpStatus.NOT_FOUND, "Not found."); }
    @ExceptionHandler(Exception.class) public ResponseEntity<Map<String,String>> serverError(Exception ex) {
        log.error("Unhandled API error", ex);
        return r(HttpStatus.INTERNAL_SERVER_ERROR, "An unexpected server error occurred.");
    }
}
