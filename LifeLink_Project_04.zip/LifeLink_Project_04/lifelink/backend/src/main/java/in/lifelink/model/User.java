package in.lifelink.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "users")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable=false, length=120) private String name;
    @Column(nullable=false, unique=true, length=190) private String email;
    @Column(name="password_hash", nullable=false, length=100) private String passwordHash;
    @Column(nullable=false, length=25) private String phone;
    @Column(nullable=false, length=100) private String city;
    @Column(nullable=false, length=100) private String district;
    @Column(nullable=false, length=100) private String state;
    @Column(nullable=false, length=20) private String role = "USER";
    @Column(name="created_at", insertable=false, updatable=false) private Instant createdAt;

    public Long getId(){return id;} public void setId(Long v){id=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String v){passwordHash=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public String getCity(){return city;} public void setCity(String v){city=v;}
    public String getDistrict(){return district;} public void setDistrict(String v){district=v;}
    public String getState(){return state;} public void setState(String v){state=v;}
    public String getRole(){return role;} public void setRole(String v){role=v;}
    public Instant getCreatedAt(){return createdAt;}
}
