package in.lifelink.controller;

import in.lifelink.service.RequestService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController @RequestMapping("/api/requests")
public class RequestController {
    private final RequestService service;
    public RequestController(RequestService service){this.service=service;}
    @GetMapping public List<Map<String,Object>> list(Authentication auth){return service.list(auth.getName());}
    @PostMapping public Map<String,Object> create(Authentication auth,@RequestBody Map<String,Object> body){return service.create(auth.getName(),body);}
    @GetMapping("/{id}/matches") public List<Map<String,Object>> matches(Authentication auth,@PathVariable Long id){return service.matches(auth.getName(),id);}
    @PostMapping("/{id}/complete") public Map<String,Object> complete(Authentication auth,@PathVariable Long id){return service.updateStatus(auth.getName(),id,"COMPLETED");}
    @PostMapping("/{id}/cancel") public Map<String,Object> cancel(Authentication auth,@PathVariable Long id){return service.updateStatus(auth.getName(),id,"CANCELLED");}
}
