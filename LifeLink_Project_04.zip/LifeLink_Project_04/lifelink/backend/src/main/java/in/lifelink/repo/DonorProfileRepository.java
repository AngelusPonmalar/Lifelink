package in.lifelink.repo;

import in.lifelink.model.DonorProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface DonorProfileRepository extends JpaRepository<DonorProfile, Long> {
    List<DonorProfile> findByBloodGroupAndAvailableTrue(String bloodGroup);
    Optional<DonorProfile> findByUserId(Long userId);
}
