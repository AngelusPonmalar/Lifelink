package in.lifelink.controller;

import in.lifelink.model.BloodRequest;
import in.lifelink.service.RequestService;
import in.lifelink.util.ApiException;
import in.lifelink.util.Audit;
import in.lifelink.util.Validators;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api")
public class DonorWorkflowController {
  private final JdbcTemplate db; private final RequestService requestService; private final Audit audit;
  public DonorWorkflowController(JdbcTemplate db, RequestService requestService, Audit audit){this.db=db;this.requestService=requestService;this.audit=audit;}
  private long uid(String email){
    List<Long> ids=db.queryForList("SELECT id FROM users WHERE email=?",Long.class,email);
    if(ids.isEmpty()) throw ApiException.unauthorized("Account not found. Please log in again.");
    return ids.get(0);
  }
  private void notify(long user,String title,String body,Long requestId){db.update("INSERT INTO notifications(user_id,title,body,request_id) VALUES(?,?,?,?)",user,title,body,requestId);}
  private Map<String,Object> one(String sql,String notFound,Object... args){
    List<Map<String,Object>> rows=db.queryForList(sql,args); if(rows.isEmpty()) throw ApiException.notFound(notFound); return rows.get(0);
  }

  // ---------- profile (donor details + location) ----------
  @GetMapping("/donors/profile") public Map<String,Object> profile(Authentication a){
    long u=uid(a.getName());
    Map<String,Object> loc=one("SELECT city,district,state,phone FROM users WHERE id=?","Account not found.",u);
    var rows=db.queryForList("SELECT d.id,d.blood_group bloodGroup,d.available,d.last_donation_date lastDonationDate FROM donor_profiles d WHERE d.user_id=?",u);
    Map<String,Object> out=new LinkedHashMap<>(); if(!rows.isEmpty()) out.putAll(rows.get(0));
    out.put("registered",!rows.isEmpty()); out.putAll(loc); return out;
  }
  @PostMapping("/donors/profile") @Transactional public Map<String,Object> saveProfile(Authentication a,@RequestBody Map<String,Object>b){
    long u=uid(a.getName()); String group=Validators.bloodGroup(b.get("bloodGroup"));
    boolean available=Boolean.parseBoolean(String.valueOf(b.getOrDefault("available",true)));
    Object last=Validators.lastDonation(b.get("lastDonationDate"),requestService.today());
    if(b.get("city")!=null||b.get("district")!=null||b.get("state")!=null)
      db.update("UPDATE users SET city=?,district=?,state=? WHERE id=?",Validators.text(b.get("city"),"city",100),Validators.text(b.get("district"),"district",100),Validators.text(b.get("state"),"state",100),u);
    int n=db.update("UPDATE donor_profiles SET blood_group=?,available=?,last_donation_date=? WHERE user_id=?",group,available,last,u);
    if(n==0) db.update("INSERT INTO donor_profiles(user_id,blood_group,available,last_donation_date) VALUES(?,?,?,?)",u,group,available,last);
    audit.log(u,"DONOR_PROFILE_SAVED","DONOR_PROFILE",u,null);
    return profile(a);
  }

  // ---------- donor inbox ----------
  @GetMapping("/donors/incoming") public List<Map<String,Object>> incoming(Authentication a){
    long u=uid(a.getName());
    return db.queryForList("SELECT rr.id recipientId,rr.request_id requestId,CASE WHEN rr.response_status='PENDING' AND br.status<>'OPEN' THEN 'CLOSED' ELSE rr.response_status END responseStatus,rr.contact_share_approved contactShared,br.patient_name patientName,br.blood_group bloodGroup,br.units_required units,br.hospital_name hospitalName,br.city,br.district,br.required_date requiredDate,br.urgency,br.status requestStatus FROM request_recipients rr JOIN blood_requests br ON br.id=rr.request_id WHERE rr.donor_user_id=? ORDER BY rr.id DESC",u);
  }

  // ---------- requester invites ----------
  @PostMapping("/requests/{id}/invite") @Transactional public Map<String,Object> invite(Authentication a,@PathVariable long id,@RequestBody Map<String,Object>b){
    long requester=uid(a.getName());
    long donor; try{donor=Long.parseLong(String.valueOf(b.get("donorUserId")));}catch(NumberFormatException e){throw new IllegalArgumentException("donorUserId is required.");}
    BloodRequest req=requestService.ownedRequest(id,requester);
    if(donor==requester) throw new IllegalArgumentException("You cannot invite yourself.");
    if(!requestService.isOpen(req)) throw ApiException.conflict("This request is no longer open.");
    if(!requestService.eligibleDonor(req,donor)) throw new IllegalArgumentException("This donor is not currently eligible for this request.");
    Integer existing=db.queryForObject("SELECT COUNT(*) FROM request_recipients WHERE request_id=? AND donor_user_id=?",Integer.class,id,donor);
    if(existing!=null&&existing>0) throw ApiException.conflict("This donor has already been invited to this request.");
    db.update("INSERT INTO request_recipients(request_id,donor_user_id,response_status) VALUES(?,?,'PENDING')",id,donor);
    notify(donor,"New blood request","You have received a matching blood request. Review it in Incoming requests.",id);
    audit.log(requester,"DONOR_INVITED","BLOOD_REQUEST",id,"donor="+donor);
    return Map.of("message","Invitation sent.");
  }

  // ---------- donor responds (consent-first) ----------
  @PostMapping("/donors/incoming/{recipientId}/respond") @Transactional public Map<String,Object> respond(Authentication a,@PathVariable long recipientId,@RequestBody Map<String,Object>b){
    long donor=uid(a.getName()); String status=String.valueOf(b.get("status")).toUpperCase(Locale.ROOT);
    if(!List.of("ACCEPTED","REJECTED").contains(status)) throw new IllegalArgumentException("Choose ACCEPTED or REJECTED.");
    Map<String,Object> row=one("SELECT rr.request_id,rr.response_status,br.requester_id,br.status request_status,br.required_date FROM request_recipients rr JOIN blood_requests br ON br.id=rr.request_id WHERE rr.id=? AND rr.donor_user_id=?","Invitation not found.",recipientId,donor);
    if(!"OPEN".equals(row.get("request_status"))) throw ApiException.conflict("This request is no longer open.");
    if(!"PENDING".equals(row.get("response_status"))) throw ApiException.conflict("This invitation has already been answered.");
    boolean consent=Boolean.parseBoolean(String.valueOf(b.getOrDefault("shareContact",false)));
    if("ACCEPTED".equals(status)&&!consent) throw new IllegalArgumentException("Contact-sharing consent is required before accepting.");
    int changed=db.update("UPDATE request_recipients SET response_status=?,responded_at=CURRENT_TIMESTAMP,contact_share_approved=? WHERE id=? AND response_status='PENDING'",status,"ACCEPTED".equals(status),recipientId);
    if(changed==0) throw ApiException.conflict("This invitation has already been answered.");
    long requester=((Number)row.get("requester_id")).longValue(); long request=((Number)row.get("request_id")).longValue();
    if("ACCEPTED".equals(status)) {
      int upd=db.update("UPDATE contact_consents SET granted=TRUE,revoked_at=NULL,granted_at=CURRENT_TIMESTAMP WHERE request_id=? AND donor_user_id=? AND requester_user_id=?",request,donor,requester);
      if(upd==0) db.update("INSERT INTO contact_consents(request_id,donor_user_id,requester_user_id,granted) VALUES(?,?,?,TRUE)",request,donor,requester);
      notify(requester,"Donor accepted your request","A donor accepted and agreed to share their contact details for this request.",request);
      audit.log(donor,"CONSENT_GRANTED","BLOOD_REQUEST",request,"requester="+requester);
    } else { notify(requester,"Donor declined your request","A donor declined your blood request invitation.",request); audit.log(donor,"INVITE_REJECTED","BLOOD_REQUEST",request,null); }
    return Map.of("message","ACCEPTED".equals(status)?"You accepted and agreed to share your contact details with this requester.":"You declined this request.","status",status);
  }

  @PostMapping("/donors/incoming/{recipientId}/withdraw-consent") @Transactional public Map<String,Object> withdrawConsent(Authentication a,@PathVariable long recipientId){
    long donor=uid(a.getName());
    Map<String,Object> row=one("SELECT rr.request_id,rr.response_status,br.requester_id FROM request_recipients rr JOIN blood_requests br ON br.id=rr.request_id WHERE rr.id=? AND rr.donor_user_id=?","Invitation not found.",recipientId,donor);
    long req=((Number)row.get("request_id")).longValue(); long requester=((Number)row.get("requester_id")).longValue();
    db.update("UPDATE contact_consents SET granted=FALSE,revoked_at=CURRENT_TIMESTAMP WHERE request_id=? AND donor_user_id=? AND requester_user_id=? AND granted=TRUE",req,donor,requester);
    // Without consent the acceptance cannot stand: back to PENDING so the donor can decide again later.
    int n=db.update("UPDATE request_recipients SET contact_share_approved=FALSE,response_status=CASE WHEN response_status='ACCEPTED' THEN 'PENDING' ELSE response_status END,responded_at=CASE WHEN response_status='ACCEPTED' THEN NULL ELSE responded_at END WHERE id=? AND donor_user_id=? AND response_status IN ('ACCEPTED','PENDING')",recipientId,donor);
    if(n==0) throw ApiException.conflict("There is no active consent to withdraw for this invitation.");
    notify(requester,"Donor withdrew contact consent","A donor withdrew permission to share contact details for your request.",req);
    audit.log(donor,"CONSENT_WITHDRAWN","BLOOD_REQUEST",req,"requester="+requester);
    return Map.of("message","Contact-sharing consent withdrawn. Your contact details are no longer visible to the requester.");
  }

  // ---------- requester views responses (contact only with active consent) ----------
  @GetMapping("/requests/{id}/responses") public List<Map<String,Object>> responses(Authentication a,@PathVariable long id){
    long requester=uid(a.getName()); requestService.ownedRequest(id,requester);
    List<Map<String,Object>> rows=db.queryForList("SELECT rr.id recipientId,rr.donor_user_id donorUserId,rr.response_status responseStatus,rr.responded_at respondedAt,br.status requestStatus,u.name fullName,u.phone phone,u.email email,u.city city,u.district district,d.blood_group bloodGroup,rr.contact_share_approved shared,(SELECT COUNT(*) FROM contact_consents cc WHERE cc.request_id=rr.request_id AND cc.donor_user_id=rr.donor_user_id AND cc.requester_user_id=br.requester_id AND cc.granted=1 AND cc.revoked_at IS NULL) activeConsents FROM request_recipients rr JOIN blood_requests br ON br.id=rr.request_id JOIN users u ON u.id=rr.donor_user_id LEFT JOIN donor_profiles d ON d.user_id=u.id WHERE rr.request_id=? AND br.requester_id=? ORDER BY rr.id DESC",id,requester);
    List<Map<String,Object>> out=new ArrayList<>();
    for(Map<String,Object> r:rows){
      boolean visible="OPEN".equals(r.get("requestStatus"))&&"ACCEPTED".equals(r.get("responseStatus"))&&truthy(r.get("shared"))&&((Number)r.get("activeConsents")).intValue()>0;
      String full=String.valueOf(r.get("fullName")); Map<String,Object> m=new LinkedHashMap<>();
      m.put("recipientId",r.get("recipientId")); m.put("donorUserId",r.get("donorUserId")); m.put("responseStatus",r.get("responseStatus")); m.put("respondedAt",r.get("respondedAt"));
      m.put("requestStatus",r.get("requestStatus")); m.put("bloodGroup",r.get("bloodGroup")); m.put("city",r.get("city")); m.put("district",r.get("district")); m.put("contactVisible",visible);
      m.put("donorName",visible?full:full.trim().split("\\s+")[0]); m.put("phone",visible?r.get("phone"):null); m.put("email",visible?r.get("email"):null);
      if(visible){
        Integer seen=db.queryForObject("SELECT COUNT(*) FROM audit_logs WHERE action='CONTACT_REVEALED' AND actor_user_id=? AND entity_type='BLOOD_REQUEST' AND entity_id=? AND details=?",Integer.class,requester,id,"donor="+r.get("donorUserId"));
        if(seen==null||seen==0) audit.log(requester,"CONTACT_REVEALED","BLOOD_REQUEST",id,"donor="+r.get("donorUserId"));
      }
      out.add(m);
    }
    return out;
  }

  private static boolean truthy(Object o){return o instanceof Boolean x?x:o instanceof Number n?n.intValue()!=0:"true".equalsIgnoreCase(String.valueOf(o));}

  // ---------- notifications / history ----------
  @GetMapping("/notifications") public List<Map<String,Object>> notifications(Authentication a){return db.queryForList("SELECT id,title,body,request_id requestId,read_at readAt,created_at createdAt FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100",uid(a.getName()));}
  @PostMapping("/notifications/{id}/read") public Map<String,Object> markRead(Authentication a,@PathVariable long id){
    int n=db.update("UPDATE notifications SET read_at=COALESCE(read_at,CURRENT_TIMESTAMP) WHERE id=? AND user_id=?",id,uid(a.getName()));
    if(n==0) throw ApiException.notFound("Notification not found."); return Map.of("message","Notification marked as read.");
  }
  @PostMapping("/notifications/read-all") public Map<String,Object> markAllRead(Authentication a){
    int n=db.update("UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE user_id=? AND read_at IS NULL",uid(a.getName())); return Map.of("message","All notifications marked as read.","updated",n);
  }
  @GetMapping("/donors/history") public List<Map<String,Object>> donorHistory(Authentication a){
    return db.queryForList("SELECT rr.id recipientId,br.id requestId,br.patient_name patientName,br.blood_group bloodGroup,br.hospital_name hospitalName,br.city,br.status requestStatus,rr.response_status responseStatus,rr.responded_at respondedAt,rr.completed_at completedAt FROM request_recipients rr JOIN blood_requests br ON br.id=rr.request_id WHERE rr.donor_user_id=? AND rr.response_status IN ('ACCEPTED','COMPLETED') ORDER BY rr.id DESC",uid(a.getName()));
  }
  @PostMapping("/donors/incoming/{recipientId}/complete") @Transactional public Map<String,Object> completeDonation(Authentication a,@PathVariable long recipientId){
    long donor=uid(a.getName());
    int n=db.update("UPDATE request_recipients rr JOIN blood_requests br ON br.id=rr.request_id SET rr.response_status='COMPLETED',rr.completed_at=CURRENT_TIMESTAMP WHERE rr.id=? AND rr.donor_user_id=? AND rr.response_status='ACCEPTED' AND br.status='OPEN'",recipientId,donor);
    if(n==0) throw ApiException.conflict("Only accepted donations on open requests can be marked completed.");
    audit.log(donor,"DONATION_COMPLETED","REQUEST_RECIPIENT",recipientId,null);
    return Map.of("message","Donation marked completed.");
  }

  // ---------- admin ----------
  @GetMapping("/admin/audit-logs") public List<Map<String,Object>> auditLogs(){return db.queryForList("SELECT id,actor_user_id actorUserId,action,entity_type entityType,entity_id entityId,details,created_at createdAt FROM audit_logs ORDER BY id DESC LIMIT 200");}
}
