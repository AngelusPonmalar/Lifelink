package in.lifelink.controller;

import in.lifelink.service.AuthService;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth){this.auth=auth;}
    @PostMapping("/register") public Map<String,Object> register(@RequestBody Map<String,String> body){return auth.register(body);}
    @PostMapping("/login") public Map<String,Object> login(@RequestBody Map<String,String> body){return auth.login(body);}
}
