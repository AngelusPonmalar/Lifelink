package in.lifelink.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Pure validation / normalization helpers (unit tested, no Spring dependencies). */
public final class Validators {
    private Validators() {}
    public static final List<String> BLOOD_GROUPS = List.of("A+","A-","B+","B-","AB+","AB-","O+","O-");
    public static final List<String> URGENCIES = List.of("NORMAL","URGENT","CRITICAL");
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    public static String bloodGroup(Object v) {
        String g = v == null ? "" : v.toString().trim().toUpperCase(Locale.ROOT);
        if (!BLOOD_GROUPS.contains(g)) throw new IllegalArgumentException("Choose a valid blood group.");
        return g;
    }
    public static String urgency(Object v) {
        String u = v == null || v.toString().isBlank() ? "URGENT" : v.toString().trim().toUpperCase(Locale.ROOT);
        if (!URGENCIES.contains(u)) throw new IllegalArgumentException("Urgency must be NORMAL, URGENT or CRITICAL.");
        return u;
    }
    public static String email(String v) {
        String e = text(v, "email", 190).toLowerCase(Locale.ROOT);
        if (!EMAIL.matcher(e).matches()) throw new IllegalArgumentException("Enter a valid email address.");
        return e;
    }
    /** Accepts "9876543210", "+91 98765 43210", "+91-98765-43210"; returns "+919876543210". */
    public static String phone(String v) {
        String p = text(v, "phone", 25).replaceAll("[\\s-]", "");
        if (p.matches("^[6-9][0-9]{9}$")) p = "+91" + p;
        if (!p.matches("^\\+91[6-9][0-9]{9}$")) throw new IllegalArgumentException("Phone must be a valid Indian mobile number (+91 followed by 10 digits).");
        return p;
    }
    /** Required, trimmed, whitespace-collapsed, length-limited text. */
    public static String text(Object v, String field, int max) {
        if (v == null || v.toString().isBlank()) throw new IllegalArgumentException(field + " is required.");
        String s = v.toString().trim().replaceAll("\\s+", " ");
        if (s.length() > max) throw new IllegalArgumentException(field + " must be at most " + max + " characters.");
        return s;
    }
    public static String optionalText(Object v, int max, String field) {
        if (v == null) return "";
        String s = v.toString().trim();
        if (s.equalsIgnoreCase("null")) return "";
        if (s.length() > max) throw new IllegalArgumentException(field + " must be at most " + max + " characters.");
        return s;
    }
    public static int units(Object v) {
        int n;
        try { n = Integer.parseInt(String.valueOf(v == null ? 1 : v).trim()); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Units must be a whole number between 1 and 20."); }
        if (n < 1 || n > 20) throw new IllegalArgumentException("Units must be between 1 and 20.");
        return n;
    }
    public static LocalDate date(Object v, String field) {
        try { return LocalDate.parse(String.valueOf(v).trim()); }
        catch (DateTimeParseException | NullPointerException ex) { throw new IllegalArgumentException("Enter a valid " + field + " (YYYY-MM-DD)."); }
    }
    public static LocalDate requiredDate(Object v, LocalDate today) {
        LocalDate d = date(v, "required date");
        if (d.isBefore(today)) throw new IllegalArgumentException("Required date cannot be in the past.");
        return d;
    }
    /** Returns null for blank input. */
    public static LocalDate lastDonation(Object v, LocalDate today) {
        if (v == null || v.toString().isBlank()) return null;
        LocalDate d = date(v, "last donation date");
        if (d.isAfter(today)) throw new IllegalArgumentException("Last donation date cannot be in the future.");
        return d;
    }
    public static String norm(String s) {
        return s == null ? "" : s.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }
    public static boolean sameLocation(String stateA, String cityA, String districtA, String stateB, String cityB, String districtB) {
        return norm(stateA).equals(norm(stateB)) && (norm(cityA).equals(norm(cityB)) || norm(districtA).equals(norm(districtB)));
    }
    public static String password(String v) {
        if (v == null || v.length() < 8) throw new IllegalArgumentException("Password must be at least 8 characters.");
        if (v.length() > 72) throw new IllegalArgumentException("Password must be at most 72 characters.");
        return v;
    }
}
