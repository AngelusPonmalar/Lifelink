package in.lifelink.repo;
import in.lifelink.model.BloodRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {
    List<BloodRequest> findByRequesterIdOrderByCreatedAtDesc(Long requesterId);
    Optional<BloodRequest> findByIdAndRequesterId(Long id, Long requesterId);
}
