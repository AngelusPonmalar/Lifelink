ALTER TABLE request_recipients ADD COLUMN contact_share_approved BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE request_recipients ADD COLUMN completed_at TIMESTAMP NULL;
ALTER TABLE request_recipients ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
CREATE INDEX idx_recipient_donor_status ON request_recipients(donor_user_id, response_status);
CREATE INDEX idx_notification_user_created ON notifications(user_id, created_at);
