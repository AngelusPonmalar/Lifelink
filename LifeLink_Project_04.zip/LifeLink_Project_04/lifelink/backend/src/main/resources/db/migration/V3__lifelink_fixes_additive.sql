-- Additive only: no DROP, DELETE, TRUNCATE or data rewrites.
ALTER TABLE notifications ADD COLUMN request_id BIGINT NULL;
CREATE INDEX idx_notification_user_read ON notifications(user_id, read_at);
CREATE INDEX idx_users_location ON users(state, city, district);
CREATE INDEX idx_blood_requests_status_date ON blood_requests(status, required_date);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);
