package in.lifelink;

import in.lifelink.security.JwtService;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class JwtServiceTest {
    private static final String SECRET = "unit-test-secret-unit-test-secret-1234";
    @Test void roundTripReturnsSubject() {
        JwtService s = new JwtService(SECRET, 60_000);
        assertEquals("a@b.com", s.subject(s.createToken(7L, "a@b.com", "USER")));
    }
    @Test void rejectsShortSecret() { assertThrows(IllegalArgumentException.class, () -> new JwtService("short", 1000)); }
    @Test void rejectsTamperedAndExpiredTokens() throws Exception {
        JwtService s = new JwtService(SECRET, 60_000);
        String t = s.createToken(1L, "a@b.com", "USER");
        assertThrows(RuntimeException.class, () -> s.subject(t + "x"));
        JwtService expired = new JwtService(SECRET, -1000);
        assertThrows(RuntimeException.class, () -> s.subject(expired.createToken(1L, "a@b.com", "USER")));
        JwtService other = new JwtService("another-secret-another-secret-123456", 60_000);
        assertThrows(RuntimeException.class, () -> other.subject(t));
    }
}
