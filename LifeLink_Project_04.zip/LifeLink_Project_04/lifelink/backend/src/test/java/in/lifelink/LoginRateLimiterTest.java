package in.lifelink;

import in.lifelink.util.LoginRateLimiter;
import org.junit.jupiter.api.Test;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicLong;
import static org.junit.jupiter.api.Assertions.*;

class LoginRateLimiterTest {
    @Test void blocksAfterMaxFailuresAndRecoversAfterWindow() {
        AtomicLong now = new AtomicLong(1_000);
        LoginRateLimiter l = new LoginRateLimiter(3, Duration.ofMinutes(1), now::get);
        for (int i = 0; i < 3; i++) { assertFalse(l.isBlocked("a@b.com")); l.recordFailure("a@b.com"); }
        assertTrue(l.isBlocked("a@b.com"));
        assertFalse(l.isBlocked("other@b.com"));
        now.addAndGet(61_000);
        assertFalse(l.isBlocked("a@b.com"));
    }
    @Test void successfulLoginResetsCounter() {
        LoginRateLimiter l = new LoginRateLimiter(2, Duration.ofMinutes(1));
        l.recordFailure("x"); l.recordFailure("x"); assertTrue(l.isBlocked("x"));
        l.reset("x"); assertFalse(l.isBlocked("x"));
    }
}
