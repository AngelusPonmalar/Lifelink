package in.lifelink;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import java.time.LocalDate;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

/**
 * End-to-end consent workflow against a REAL, DISPOSABLE MySQL test database (never your real data).
 * Runs only when LIFELINK_IT_DB_URL is set, e.g.
 *   LIFELINK_IT_DB_URL=jdbc:mysql://localhost:3306/lifelink_test LIFELINK_IT_DB_USER=root LIFELINK_IT_DB_PASSWORD=... mvn test
 */
@EnabledIfEnvironmentVariable(named = "LIFELINK_IT_DB_URL", matches = ".+")
@SpringBootTest(properties = "app.jwt.secret=integration-test-secret-integration-test-123")
@AutoConfigureMockMvc
class ConsentWorkflowIT {
    @DynamicPropertySource static void db(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", () -> System.getenv("LIFELINK_IT_DB_URL"));
        r.add("spring.datasource.username", () -> System.getenv().getOrDefault("LIFELINK_IT_DB_USER", "root"));
        r.add("spring.datasource.password", () -> System.getenv().getOrDefault("LIFELINK_IT_DB_PASSWORD", ""));
    }
    @Autowired MockMvc mvc; @Autowired ObjectMapper om;

    private MvcResult call(MockHttpServletRequestBuilder b, String token, Object body) throws Exception {
        b.contentType(MediaType.APPLICATION_JSON);
        if (token != null) b.header("Authorization", "Bearer " + token);
        if (body != null) b.content(om.writeValueAsString(body));
        return mvc.perform(b).andReturn();
    }
    private JsonNode json(MvcResult r) throws Exception { return om.readTree(r.getResponse().getContentAsString()); }

    private String register(String email, String phone, boolean donor) throws Exception {
        Map<String,String> body = new java.util.HashMap<>(Map.of("name","Test User","email",email,"password","password123","phone",phone,
            "city","Chennai","district","Chennai","state","Tamil Nadu"));
        if (donor) { body.put("registerAsDonor","true"); body.put("bloodGroup","O+"); }
        MvcResult r = call(post("/api/auth/register"), null, body);
        assertEquals(200, r.getResponse().getStatus(), r.getResponse().getContentAsString());
        return json(r).get("token").asText();
    }

    @Test void fullConsentFirstWorkflow() throws Exception {
        String s = String.valueOf(System.nanoTime());
        String requester = register("req" + s + "@example.com", "+919876500001", false);
        String donor = register("don" + s + "@example.com", "+919876500002", true);

        MvcResult created = call(post("/api/requests"), requester, Map.of("patientName","Patient","bloodGroup","O+","units",1,"hospitalName","City Hospital",
            "city","Chennai","district","Chennai","state","Tamil Nadu","requiredDate",LocalDate.now().plusDays(3).toString(),"urgency","URGENT"));
        assertEquals(200, created.getResponse().getStatus(), created.getResponse().getContentAsString());
        long reqId = json(created).get("id").asLong();

        JsonNode matches = json(call(get("/api/requests/" + reqId + "/matches"), requester, null));
        assertTrue(matches.size() >= 1, "registered donor must appear in matches");
        long donorUserId = 0;
        for (JsonNode m : matches) if ("Test".equals(m.get("displayName").asText())) donorUserId = m.get("donorUserId").asLong();
        assertTrue(donorUserId > 0);

        assertEquals(200, call(post("/api/requests/" + reqId + "/invite"), requester, Map.of("donorUserId", donorUserId)).getResponse().getStatus());
        assertEquals(409, call(post("/api/requests/" + reqId + "/invite"), requester, Map.of("donorUserId", donorUserId)).getResponse().getStatus(), "duplicate invite");

        JsonNode inbox = json(call(get("/api/donors/incoming"), donor, null));
        long recipientId = inbox.get(0).get("recipientId").asLong();
        assertEquals("PENDING", inbox.get(0).get("responseStatus").asText());

        // NO: accept without consent is refused; still pending; no contact revealed
        assertEquals(400, call(post("/api/donors/incoming/" + recipientId + "/respond"), donor, Map.of("status","ACCEPTED","shareContact",false)).getResponse().getStatus());
        JsonNode before = json(call(get("/api/requests/" + reqId + "/responses"), requester, null));
        assertEquals("PENDING", before.get(0).get("responseStatus").asText());
        assertTrue(before.get(0).get("phone").isNull());

        // YES: accept with consent -> contact visible only to this requester
        assertEquals(200, call(post("/api/donors/incoming/" + recipientId + "/respond"), donor, Map.of("status","ACCEPTED","shareContact",true)).getResponse().getStatus());
        JsonNode after = json(call(get("/api/requests/" + reqId + "/responses"), requester, null));
        assertEquals("ACCEPTED", after.get(0).get("responseStatus").asText());
        assertEquals("+919876500002", after.get(0).get("phone").asText());
        String other = register("oth" + s + "@example.com", "+919876500003", false);
        assertEquals(404, call(get("/api/requests/" + reqId + "/responses"), other, null).getResponse().getStatus(), "other users cannot read responses");

        // Withdrawal: access revoked immediately
        assertEquals(200, call(post("/api/donors/incoming/" + recipientId + "/withdraw-consent"), donor, null).getResponse().getStatus());
        JsonNode revoked = json(call(get("/api/requests/" + reqId + "/responses"), requester, null));
        assertTrue(revoked.get(0).get("phone").isNull());
        assertTrue(revoked.get(0).get("email").isNull());

        // Re-accept, then cancel: contact hidden, donor sees CLOSED/CANCELLED and is notified
        assertEquals(200, call(post("/api/donors/incoming/" + recipientId + "/respond"), donor, Map.of("status","ACCEPTED","shareContact",true)).getResponse().getStatus());
        assertEquals(200, call(post("/api/requests/" + reqId + "/cancel"), requester, null).getResponse().getStatus());
        assertTrue(json(call(get("/api/requests/" + reqId + "/responses"), requester, null)).get(0).get("phone").isNull());
        assertEquals("CANCELLED", json(call(get("/api/donors/incoming"), donor, null)).get(0).get("requestStatus").asText());
        assertEquals(409, call(post("/api/donors/incoming/" + recipientId + "/respond"), donor, Map.of("status","REJECTED")).getResponse().getStatus());
    }
    @Test void invalidTokenGets401Json() throws Exception {
        MvcResult r = call(get("/api/requests"), "garbage", null);
        assertEquals(401, r.getResponse().getStatus());
        assertFalse(json(r).get("message").asText().isBlank());
    }
}
