package in.lifelink;

import in.lifelink.util.Validators;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class ValidatorsTest {
    private final LocalDate today = LocalDate.of(2026, 11, 1);

    @Test void bloodGroupAcceptsAllEightAndRejectsOthers() {
        for (String g : new String[]{"A+","A-","B+","B-","AB+","AB-","O+","O-"}) assertEquals(g, Validators.bloodGroup(g));
        assertEquals("O+", Validators.bloodGroup(" o+ "));
        assertThrows(IllegalArgumentException.class, () -> Validators.bloodGroup("X+"));
        assertThrows(IllegalArgumentException.class, () -> Validators.bloodGroup(""));
        assertThrows(IllegalArgumentException.class, () -> Validators.bloodGroup(null));
    }
    @Test void urgencyAllowList() {
        assertEquals("CRITICAL", Validators.urgency("critical"));
        assertEquals("URGENT", Validators.urgency(null));
        assertThrows(IllegalArgumentException.class, () -> Validators.urgency("HIGH"));
    }
    @Test void phoneIsNormalisedAndValidated() {
        assertEquals("+919876543210", Validators.phone("+91 98765 43210"));
        assertEquals("+919876543210", Validators.phone("9876543210"));
        assertThrows(IllegalArgumentException.class, () -> Validators.phone("12345"));
        assertThrows(IllegalArgumentException.class, () -> Validators.phone("+911234567890"));
    }
    @Test void emailValidation() {
        assertEquals("a@b.com", Validators.email(" A@B.com "));
        assertThrows(IllegalArgumentException.class, () -> Validators.email("not-an-email"));
    }
    @Test void textTrimsCollapsesAndLimitsLength() {
        assertEquals("Anna Nagar", Validators.text("  Anna   Nagar ", "city", 100));
        assertThrows(IllegalArgumentException.class, () -> Validators.text("x".repeat(101), "city", 100));
        assertThrows(IllegalArgumentException.class, () -> Validators.text("   ", "city", 100));
    }
    @Test void nullNotesBecomeEmptyNotTheWordNull() {
        assertEquals("", Validators.optionalText(null, 1000, "notes"));
        assertEquals("", Validators.optionalText("null", 1000, "notes"));
        assertThrows(IllegalArgumentException.class, () -> Validators.optionalText("x".repeat(1001), 1000, "notes"));
    }
    @Test void unitsRange() {
        assertEquals(3, Validators.units("3"));
        assertThrows(IllegalArgumentException.class, () -> Validators.units("0"));
        assertThrows(IllegalArgumentException.class, () -> Validators.units("21"));
        assertThrows(IllegalArgumentException.class, () -> Validators.units("abc"));
    }
    @Test void requiredDateRules() {
        assertEquals(today, Validators.requiredDate("2026-11-01", today));
        assertThrows(IllegalArgumentException.class, () -> Validators.requiredDate("2026-10-31", today));
        assertThrows(IllegalArgumentException.class, () -> Validators.requiredDate("01/11/2026", today));
        assertThrows(IllegalArgumentException.class, () -> Validators.requiredDate(null, today));
    }
    @Test void lastDonationCannotBeInFuture() {
        assertNull(Validators.lastDonation("", today));
        assertEquals(LocalDate.of(2026, 1, 1), Validators.lastDonation("2026-01-01", today));
        assertThrows(IllegalArgumentException.class, () -> Validators.lastDonation("2026-12-01", today));
    }
    @Test void locationMatchingIgnoresCaseAndWhitespaceButNotState() {
        assertTrue(Validators.sameLocation("Tamil Nadu", "Chennai ", "Chennai", "tamil  nadu", "chennai", "Chennai"));
        assertTrue(Validators.sameLocation("Tamil Nadu", "Tambaram", "Chengalpattu", "Tamil Nadu", "Chennai", "chengalpattu"));
        assertFalse(Validators.sameLocation("Kerala", "Chennai", "Chennai", "Tamil Nadu", "Chennai", "Chennai"));
        assertFalse(Validators.sameLocation("Tamil Nadu", "Madurai", "Madurai", "Tamil Nadu", "Chennai", "Chennai"));
    }
    @Test void passwordLength() {
        assertThrows(IllegalArgumentException.class, () -> Validators.password("short"));
        assertEquals("longenough", Validators.password("longenough"));
    }
}
