# LifeLink audit fix report

Status = changed in source. **None of it has been compiled or run** (see Test report).

| ID | Status | Change |
|---|---|---|
| LL-01 | Fixed in source (unverified) | Sign-up has donor checkbox + required blood group (no default); after non-donor sign-up user is sent to Donor profile; profile form no longer defaults to O+. |
| LL-02 | Fixed in source (unverified) | Refresh on every page open, 20s polling, refresh buttons, unread count; responses re-fetched on poll. |
| LL-03 | Fixed in source (unverified) | Cancel/Complete buttons with confirmation on OPEN requests. |
| LL-04 | Fixed in source (unverified) | Cancel/complete/expiry: pending invitations set CLOSED, consents revoked, donors notified; inbox shows request status and hides actions. |
| LL-05 | Fixed in source (unverified) | Responses refetched after invite; buttons disabled while busy. |
| LL-06 | Fixed in source (unverified) | Trim/normalize on save and compare; state compared; single eligibility rule for matches and invite; location editable in profile. |
| LL-07 | Fixed in source (unverified) | Logging catch-all; handlers for 400/404/405/409; no-row lookups return 404/409 via ApiException. |
| LL-08 | Fixed in source (unverified) | JSON 401 entry point + 403 handler; frontend logs out on 401 (not on login failures). |
| LL-09 | Fixed in source (unverified) | Contact hidden unless request OPEN, ACCEPTED, active consent; withdraw-consent endpoint + UI. |
| LL-10 | Fixed in source (unverified) | Full state reset on logout and login. |
| LL-11 | Fixed in source (unverified) | Dashboard calls load independently and show errors. |
| LL-12 | Fixed in source (unverified) | Allow-lists, length limits, phone/email format, date parsing, future last-donation, null notes handled (Validators). |
| LL-13 | Fixed in source (unverified) | No JWT secret default; failed-login limiter (5/15 min); 401 on bad credentials. |
| LL-14 | Fixed in source (unverified) | Custom modal with Yes/No/Cancel and Esc handling. |
| LL-15 | Fixed in source (unverified) | Guarded updates; consent upsert instead of duplicate insert; buttons disabled while busy. DB unique key NOT added (see README). |
| LL-16 | Fixed in source (unverified) | Self-invite, closed-request, expired checks; donor completion requires OPEN request; hourly expiry job. |
| LL-17 | Fixed in source (unverified) | Matching requires OPEN, state, normalized location, and configurable donation gap (default 90 days; a coordination filter, not medical clearance). |
| LL-18 | Fixed in source (unverified) | All async handlers go through guard() with error messages. |
| LL-19 | Fixed in source (unverified) | Hash routing (back button/refresh work), shared sidebar layout, working How it works link. |
| LL-20 | Fixed in source (unverified) | Backend uses configured zone (APP_TIMEZONE, default Asia/Kolkata); frontend uses local date. |
| LL-21 | Fixed in source (unverified) | Unread state, mark read/all, request link, formatted dates; history lists only accepted/completed. |
| LL-22 | Fixed in source (unverified) | audit_logs written for key actions incl. one-time CONTACT_REVEALED; admin read endpoint. |
| LL-23 | Fixed in source (unverified) | Legacy share-contact endpoint and wrapper removed; README updated. |
| LL-24 | Fixed in source (unverified) | Defaults aligned (lifelink / lifelink_user). |
| LL-25 | Fixed in source (unverified) | Unit tests (validators, limiter, JWT) + env-gated MySQL workflow integration test. |

Also fixed: frontend urgency values (HIGH/STANDARD) did not match backend (NORMAL/URGENT/CRITICAL); phone with spaces was rejected; Java version set to 21; P-1 Flyway guidance and optional baseline; P-3 CORS list now accepts spaces.

# Test report

| Check | Result |
|---|---|
| Frontend JSX/JS syntax (TypeScript transpile) | Passed, no diagnostics |
| `npm ci` / `vite build` | NOT RUN (no network) |
| `javac` / `mvn test` / unit tests | NOT RUN (no JDK compiler or Maven here) |
| `ConsentWorkflowIT` | NOT RUN (needs MySQL) |
| Flyway V3 on your DB | NOT RUN |
| Spring startup, CORS, timestamps, ddl-auto validate | NOT VERIFIED |

Run `mvn clean test`, `npm ci && npm run build`, then walk through the workflow manually. Expect possible small compile fixes since the backend was never compiled.
