# Deployment checklist

1. Run backend and frontend tests locally.
2. Create a managed MySQL database and run Flyway migrations.
3. Deploy Spring Boot to a host that supports Java 17+ and persistent environment configuration.
4. Set `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `JWT_SECRET`, and `CORS_ALLOWED_ORIGINS`.
5. Deploy the Vite frontend to a static host and set `VITE_API_URL` to the deployed API base URL.
6. Restrict CORS to the frontend domain, require HTTPS, and verify all role/ownership checks.
7. Add email verification, password reset, private document storage, rate limiting, monitoring, backups, and abuse handling before a public launch.
8. Do not store real bank licence documents in a public directory or expose personal details in logs.
9. Test consent and contact reveal from a separate requester account.
10. Obtain appropriate legal/privacy review before handling real personal or health-related information.
