# LifeLink Architecture

```text
React + Vite
    |
    | HTTPS JSON REST requests
    v
Spring Boot REST API
    |-- Controllers (HTTP and validation)
    |-- Services (business rules and authorization)
    |-- Repositories (Spring Data JPA)
    v
MySQL 8 (Flyway-managed schema)
```

## Main entities
- `users`: identity, email, password hash, role, location.
- `donor_profiles`: blood group, availability, last donation date.
- `blood_requests`: requester, blood group, units, hospital, location, required date, status.
- `request_recipients`: individual donor response state.
- `contact_consents`: explicit per-request consent records.
- `audit_logs`: sensitive actions that require review.

## Privacy rules
- Never return phone/email from public donor matching results.
- Request ownership must be checked server-side.
- Consent to share contact information must be explicit and tied to one request.
- Audit contact-detail access and administrative actions.
- Do not treat donor matching as medical eligibility confirmation.
