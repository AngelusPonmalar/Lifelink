# Windows 11 setup

## Prerequisites
- Java 21
- Maven 3.9+
- Node.js 20+
- MySQL 8+

## 1. Preserve and configure your database
Back up your existing LifeLink database first. Do not drop it or recreate it. Check the Flyway schema history and current V1/V2 checksums before starting the app.

Create/configure a MySQL database and user only if they do not already exist. Set environment variables in PowerShell for the current terminal:

```powershell
$env:DB_URL="jdbc:mysql://localhost:3306/lifelink"
$env:DB_USERNAME="lifelink_user"
$env:DB_PASSWORD="YOUR_EXISTING_DB_PASSWORD"
$env:JWT_SECRET="REPLACE_WITH_A_RANDOM_SECRET_AT_LEAST_32_CHARACTERS_LONG"
$env:APP_TIMEZONE="Asia/Kolkata"
$env:CORS_ALLOWED_ORIGINS="http://localhost:5173,http://127.0.0.1:5173"
```

Use your actual existing database name/user if they differ. Never commit real credentials.

## 2. Start backend
```powershell
cd backend
mvn clean test
mvn spring-boot:run
```

## 3. Start frontend (new PowerShell window)
```powershell
cd frontend
npm ci
npm run build
npm run dev
```

Open http://localhost:5173.

## 4. Deployment
Set the same environment variables in the hosting platform. Set `VITE_API_URL` at frontend build time to the deployed backend `/api` URL. Configure CORS to the exact deployed frontend origin. Use HTTPS and a managed MySQL backup policy.

## Database safety
Run `mysqldump -u lifelink_user -p lifelink > lifelink_backup.sql` before the first start. See README "Database safety (Flyway)" for checksum / baseline recovery.

## Optional integration test (disposable DB only)
```powershell
$env:LIFELINK_IT_DB_URL="jdbc:mysql://localhost:3306/lifelink_test"
$env:LIFELINK_IT_DB_USER="root"; $env:LIFELINK_IT_DB_PASSWORD="..."
mvn test
```
