# LifeLink — Blood Donation Coordination Platform

LifeLink helps people coordinate blood donation requests with donors and approved blood banks.

## Technology
- Frontend: React + Vite + JavaScript + CSS
- Backend: Java 21 + Spring Boot 3.5 + Maven
- Database: MySQL 8
- Authentication: Spring Security + JWT
- Migrations: Flyway

> Important: This is a starter implementation with working core structure and initial workflows, not a medically certified or production-audited service. Run the tests and complete the deployment/security checklist before using real personal or medical data.

## Project layout
- `frontend/` React user interface
- `backend/` Spring Boot REST API and Flyway migration
- `docs/` architecture and deployment notes

## Prerequisites
- Java 21+
- Node.js 20+
- MySQL 8+
- Maven (or use Maven Wrapper if you add it locally)

## 1. Configure MySQL
Create a database and user, for example:

```sql
CREATE DATABASE lifelink CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'lifelink_user'@'localhost' IDENTIFIED BY 'replace-with-a-strong-password';
GRANT ALL PRIVILEGES ON lifelink.* TO 'lifelink_user'@'localhost';
FLUSH PRIVILEGES;
```

Flyway creates the initial schema on backend startup.

## 2. Configure backend
Copy `backend/.env.example` values into your shell environment or set equivalent environment variables in your IDE:
- `DB_URL=jdbc:mysql://localhost:3306/lifelink`
- `DB_USERNAME=lifelink_user`
- `DB_PASSWORD=...`
- `JWT_SECRET` must be a random secret of at least 32 characters.

Then run:

```bash
cd backend
mvn spring-boot:run
```

API base URL: `http://localhost:8080/api`

Health check: `http://localhost:8080/api/health`

## 3. Configure frontend
```bash
cd frontend
npm install
npm run dev
```
Open the local URL Vite prints (normally `http://localhost:5173`).

The frontend uses `VITE_API_URL` and defaults to `http://localhost:8080/api`. Create `frontend/.env` if you need a different URL.

## Consent-first workflow
1. Requester creates a request and invites matching donors (same blood group, available, same state and city/district, outside the donation gap of `DONATION_GAP_DAYS`, default 90; set 0 to disable).
2. Donor taps Accept -> modal. **Yes**: consent saved, invitation accepted, contact visible only to that requester. **No/Cancel**: nothing is sent; invitation stays Pending; no contact revealed.
3. Donor can **Withdraw consent** any time: access ends immediately and the invitation returns to Pending.
4. Cancel/complete/expiry of a request closes pending invitations, revokes all consents, and notifies donors.

## Database safety (Flyway)
- Never drop or reset your DB. Back it up first (`mysqldump lifelink > backup.sql`).
- V1 and V2 are untouched. `V3__lifelink_fixes_additive.sql` only adds a column and indexes.
- If startup fails with *checksum mismatch*: your DB ran a different V1. Compare with `SELECT * FROM flyway_schema_history;`, then run `mvn flyway:repair` only after confirming the schema is equivalent.
- If it fails with *non-empty schema without history* and your DB already has the V1 tables (and not V2 columns): start once with `FLYWAY_BASELINE_ON_MIGRATE=true`.
- A unique key on `contact_consents` was deliberately not added (existing duplicates cannot be reconciled blindly); the code now updates instead of inserting duplicates.

## Other notes
- Errors: JSON 400/401/403/404/409/429; unexpected errors are logged on the server. Expired tokens return 401 and the UI logs out.
- Not implemented: email verification, password reset, email/SMS notifications, blood-bank portal, admin UI (an `ADMIN` role can read `/api/admin/audit-logs`; set the role manually in the DB).
- Do not use real personal/medical data before a privacy and security review.

## Tests
```bash
cd backend
mvn test
```
Unit tests run anywhere. The workflow integration test `ConsentWorkflowIT` runs only if `LIFELINK_IT_DB_URL` points to a **disposable** MySQL test database (see the class comment).

## Deployment overview
- Frontend: Vercel, Netlify, or another static React host.
- Backend: a Java-capable host/container service.
- Database: managed MySQL.
- Configure secrets as hosting environment variables. Never commit credentials.
- Set CORS to the deployed frontend origin before production.
- Use HTTPS, private storage for bank documents, backups, monitoring, rate limits, and account/email verification before public launch.

See `docs/ARCHITECTURE.md` and `docs/DEPLOYMENT.md`.


## Audit correction status

See [AUDIT_AND_TEST_REPORT.md](AUDIT_AND_TEST_REPORT.md) for the exact LL-01–LL-25 status and verification limitations. This package is a partially corrected source package, not a fully verified deploy-ready release. Follow [WINDOWS_SETUP.md](WINDOWS_SETUP.md) and back up the existing database before startup.
